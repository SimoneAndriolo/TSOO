/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

function printMS() {
    
   let nome = document.getElementById("ins_nome").value;
   let date = new Date();
   let ris = "Oggi è il " + date + " ciao " + nome + " buona giornata";
   
   document.getElementById("ris").innerHTML = ris;
   
}


