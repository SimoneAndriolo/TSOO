/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

function InviaQuiz() {

    let ris1 = document.getElementById("cuccarini").value;
    let ris2 = document.getElementById("hunziker").value;
    let ris3 = document.getElementById("montalcini").value;
    let ris4 = document.getElementById("majorana").value;

    let cor1 = "Lorella";
    let cor2 = "Michelle";
    let cor3 = "Rita";
    let cor4 = "Ettore";

    let contaPunteggio = 0;
    
    if (ris1 === cor1)(contaPunteggio = contaPunteggio *1 +10);
    if (ris2 === cor2)(contaPunteggio = contaPunteggio *1 +10);
    if (ris3 === cor3)(contaPunteggio = contaPunteggio *1 +20);
    if (ris4 === cor4)(contaPunteggio = contaPunteggio *1 +20);
    
    txt= "Il tuo punteggio è di " + contaPunteggio;
    document.getElementById("risposte").innerHTML=txt;
    txt2= "";
    if (contaPunteggio<40){
        alert("Sei stato bocciato!");
    }else{
    (contaPunteggio>40);
    alert("Sei stato promosso!");
    
    }
}





